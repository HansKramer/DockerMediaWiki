ALTER TABLE recentchanges ALTER rc_cur_id DROP NOT NULL;
