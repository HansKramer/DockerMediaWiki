ALTER TABLE /*$wgDBprefix*/page
  ADD page_links_updated varbinary(14) NULL default NULL;
