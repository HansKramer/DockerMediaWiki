ALTER TABLE /*$wgDBprefix*/profiling
  ADD pf_memory float NOT NULL default 0;
