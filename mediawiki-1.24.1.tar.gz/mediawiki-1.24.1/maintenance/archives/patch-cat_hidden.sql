-- cat_hidden is no longer used, delete it

ALTER TABLE /*$wgDBprefix*/category DROP COLUMN cat_hidden;
